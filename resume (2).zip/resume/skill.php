<?php
 error_reporting(0);
session_start();
//if there is not session set yet, set one to the request position.
if (!isset($_SESSION['Skill'])) {
	$_SESSION['Skill'] = $_REQUEST['Skill'];
}
// Without the =&, we would be copying the array
$skill =& $_SESSION['Skill'];
$lengthSkill = strlen($skill);
$sessionTestSkill = $_SESSION['Skill'];
$requestTestSkill = $_REQUEST['Skill'];


$isValidDis = false;
// if position is set and it has been updated getpos()
if(isset($_REQUEST['Skill']))
{
	if($sessionTestSkill != $requestTestSkill)
	{
		getSkill($errorPos, $skill, $isValidDis);
	}
}
// gets the position from the field and adds it to the session if it is not an empty string. if it is empty an error message is displayed
function getSkill(&$message, &$caption, &$valid)
{	
	$caption = "";	
	$display = $_REQUEST['Skill'];
	$length = strlen($display);
	if($length >= 1)
	{
		$caption = $display;
		$_SESSION['Skill'] = $display;
		$valid = true;
	}
	else 
	{
		$message = 'Please describe a skill.';
		$valid = false;
	}
}
 
require('view/page_skill.php');
?>