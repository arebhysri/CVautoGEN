
<!DOCTYPE html>
<html>
<head>
<title>Show Resume</title>
<link href="builder.css" rel="stylesheet" type="text/css" />
<link href="bootstrap.css" rel="stylesheet" type="text/css" />
<link href="bootstrap-responsive.css" rel="stylesheet" type="text/css" />

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="description" content="Emulating real sheets of paper in web documents (using HTML and CSS)">
		<link rel="stylesheet" type="text/css" href="css/sheets-of-paper-a4.css">
	
	
			

</head>
<div id="HTMLtoPDF">
<input type="button" name="download" value="Download" onclick="HTMLtoPDF()" class="btn" />
<body class="document">
		<div class="page" contenteditable="true"> 
<p class="RBody">
	<h1 class="RName">
		<?php echo($name) ?>	</h1>

	<p class="RAddress">
		<?php echo($address) ?>	</p>

	<p class="RPhones">
		<?php echo($phone) ?>	</p>


		<p class="RId_no">
		<?php echo($idno) ?>	</p>


		<p class="Email">
		<?php echo($email) ?>	</p>

	<hr width="100%">

	<h3>About me</h3>
	<p>
		<?php echo($position) ?>	</p>

		<hr width="100%">
	<h3>Employment History</h3>
	<p>
		<?php buildJobs($start, $end, $jobs) ?></p>

<hr width="100%">
			<h3>Skills</h3>
	<p>
		<?php echo($Skill) ?>	</p>

	<hr width="100%">
	<h3>Work Experience</h3>
	<p>
		<?php buildJobs($start, $end, $jobs) ?></p>


		<hr width="100%">
		<h3>Education</h3>
	<p>
		<?php buildJobs($start, $end, $edu) ?></p>

	</div>	
   <h3>Education</h3>
	<p>
		<?php buildJobs($start, $end, $edu) ?></p>

	</>

	<!-- these js files are used for making PDF -->
	<script src="jspdf.js"></script>
	<script src="jquery-2.1.3.js"></script>
	<script src="pdfFromHTML.js"></script>
</body>

</html>