<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Database Error</title>
</head>

<body>

<h2>Database Error</h2>

There was a database error.  Here are the particulars:

<p>
<?php echo $exception->getMessage(); ?>
</p>

</body>
</html>