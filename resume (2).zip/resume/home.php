<?php


require('view/page_start.php');



?>

