<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <title>CVautoGen</title>
    <link href="x.css" rel="stylesheet" type="text/css" />
    <link href="../../dist/css/bootstrap.min.css" rel="stylesheet">

  </head>
    <body>
      
      
      <h1 align="center" > CVautoGEN </h1>

              
      <ul class="nav1">
           <?php 
            if(isset($_SESSION['loggedinstring'])){
                echo $_SESSION['loggedinstring'] ;
              }
            ?>
          <li><a href="login.php">Login</a></li>
          <li><a href="logout.php" >logout</a></li>
      </ul>
      
      <div>
        <div class="boarder">
          <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="../contactForm/pages/get_details/getDetails.html">Contact Info</a></li>
            <li><a href="resume.php">View resume</a></li>
          </ul>
        </div>

        <div class="sidebar" align ="center" >
              <form action="contact.php" method="get">
                <br/>
                <br/>
                <br/>
                <p>This is a resume builder. Click Get Started to begin a new resume.</p>
                <input type="submit" name="getStarted" value="Get Started" class="btn" />
                <div style="padding-top:10px ;">
                  <p>To restore a previously saved resume click Restore Archive</p>
                  <a href="archive.php">
                    <button class="btn">Restore Archive</button>
                  </a>
                </div>
              </form>
        </div>


      </div>

    </body>
  
</html>