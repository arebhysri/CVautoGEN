﻿<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <title>CVautoGen</title>
    <link href="x.css" rel="stylesheet" type="text/css" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Favicon and touch icons -->
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">
         <link href="fonts/font-awesome.min.css" rel="stylesheet" type="text/css">
        <!-- Loading main css file -->
        <link rel="stylesheet" href="style.css">
        <script src="../js/ie-emulation-modes-warning.js"></script>
        <meta charset="utf-8">
  </head>
    <body>
      
       
      <h1 align="center" > CVautoGEN </h1>

              
      <ul class="nav1">
           <?php 
            if(isset($_SESSION['loggedinstring'])){
                echo $_SESSION['loggedinstring'] ;
              }
            ?>
          <li><a href="login.php">Login</a></li>
          <li><a href="logout.php" >logout</a></li>
      </ul>
      
      
        <div class="boarder">
          <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="getDetails.html">Contact Info</a></li>
            <li><a href="resume.php">View resume</a></li>
          </ul>
        </div>

        <div class="sidebar" align ="center" >
              
                    
                        <div class="col-sm-6 col-sm-offset-3 form-box">
                          <div class="form-top">
                            
                            <div class="form-top-right">
                              <i class="fa fa-key"></i>
                            </div>
                            </div>
                            <div class="form-bottom">
                               
                                   
                                      <?php
                                        include("header.php");
                                        extract($_POST);
                                        include("connection.php");
                                        $rs=mysql_query("select * from users where username='$name'");
                                        if (mysql_num_rows($rs)>0)
                                        {
                                          echo "<br><br><br><div class=head1>Login Id Already Exists</div>";
                                          exit;
                                        }
                                        $query="insert into users(user_id,pass,username,email) values('$uid','$pass','$name','$email')";
                                        $rs=mysql_query($query)or die("Could Not Perform the Query");

                                        echo "<br><br><br><div class=head1>Hello  $name please click to </div>";
                                        echo "<br><div class=head1><a href=login.php> Login</a></div>";
                                      ?>
                                
                            </div>
                        </div>
                        </div>
                   
                    
                       
        </div>


     
        <script src="assets/js/jquery-1.11.1.min.js"></script>
       <script src="assets/bootstrap/js/bootstrap.min.js"></script>
       
        <script src="assets/js/scripts.js"></script>
    </body>
  
</html>



</body>
</html>

