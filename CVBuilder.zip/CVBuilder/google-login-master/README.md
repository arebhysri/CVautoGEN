# google-login
A code to demonstrate google login for websites with the simplest code possible

Demo - http://packetcode.com/apps/google-login/
