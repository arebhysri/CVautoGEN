
<?php
//error_reporting(0);

$errorName=$errorAddress=$errorPhone=null;

session_start();
IF(isset($_REQUEST))
{
	$fullName =& $_REQUEST['FullName'];
	$address =& $_REQUEST['Address'];
	$phone =& $_REQUEST['Phone'];
	$email =& $_REQUEST['email'];
	$NIC =& $_REQUEST['NIC'];
}



if (isset($_SESSION['FullName'])) {
	$_SESSION['FullName'] = $_REQUEST['FullName'];
}



$fullName =& $_SESSION['FullName'];
if (isset($_SESSION['Address'])) {
	$_SESSION['Address'] = $_REQUEST['Address'];
	echo 'fdfd';
}

$address =& $_SESSION['Address'];

if (isset($_SESSION['Phone'])) {
	$_SESSION['Phone'] = $_REQUEST['Phone'];
}



$phone =& $_SESSION['Phone'];

if (isset($_SESSION['email'])) {
	$_SESSION['email'] = $_REQUEST['email'];
}

$email =& $_SESSION['email'];


if (isset($_SESSION['NIC'])) {
	$_SESSION['NIC'] = $_REQUEST['NIC'];
}

$NIC =& $_SESSION['NIC'];

if(isset($_SESSION['FullName']))
{
$sessionTestName = $_SESSION['FullName'];
}
if(isset($_REQUEST['FullName']))
{
$requestTestName = $_REQUEST['FullName'];
}

$isValidName = false;

if(isset($_REQUEST['FullName']))
{
	if($sessionTestName != $requestTestName)
	{
		getName($errorName, $fullName, $isValidName);
	}
}

if(isset($_SESSION['Address']))
{
	
$sessionTestAddress = $_SESSION['Address'];
}
if(isset($_REQUEST['Address']))
{
	$address =$_REQUEST['Address'];
$requestTestAddress = $_REQUEST['Address'];
}
$isValidAddress = false;

if(!isset($_REQUEST['Address']))
{
	if($sessionTestAddress != $requestTestAddress)
	{
		getAddress($errorAddress, $address, $isValidAddress);
	}
}

$sessionTestPhone = $_SESSION['Phone'];
$requestTestPhone = $_REQUEST['Phone'];

$isValidPhone = false;

if(!isset($_REQUEST['Phone']))
{
	if($sessionTestPhone != $requestTestPhone)
	{
		getPhone($errorPhone, $phone, $isValidPhone);
	}
}

function getName(&$message, &$caption, &$valid)
{	
	$caption = "";	
	$display = $_REQUEST['FullName'];
	$length = strlen($display);
	if($length >= 1)
	{
		$caption = $display;
		$_SESSION['FullName'] = $display;
		$valid = true;
	}
	else 
	{
		$message = 'Please enter a name.';
		$valid = false;
	}
}

function getAddress(&$message, &$caption, &$valid)
{	
	$caption = "";	
	$display = $_REQUEST['Address'];
	$length = strlen($display);
	if($length >= 1)
	{
		$caption = $display;
		$_SESSION['Address'] = $display;
		$valid = true;
	}
	else 
	{
		$message = 'Please enter a address.';
		$valid = false;
	}
}

function getPhone(&$message, &$caption, &$valid)
{	
	$caption = "";	
	$display = $_REQUEST['Phone'];
	$length = strlen($display);
	if($length >= 1)
	{
		$caption = $display;
		$_SESSION['Phone'] = $display;
		$valid = true;
	}
	else 
	{
		$message = 'Please enter a phone number.';
		$valid = false;
	}
} 
require('view/page_contact.php');
?>