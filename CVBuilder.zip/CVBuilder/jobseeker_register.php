﻿﻿﻿﻿﻿﻿﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
 <meta charset="utf-8">
    <title>CVautoGen</title>


    <link href="x.css" rel="stylesheet" type="text/css" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Favicon and touch icons -->
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">
         <link href="fonts/font-awesome.min.css" rel="stylesheet" type="text/css">
        <!-- Loading main css file -->
        <link rel="stylesheet" href="style.css">
        <script src="../js/ie-emulation-modes-warning.js"></script>
        <meta charset="utf-8">

<script type="text/javascript" language="javascript">
    function ColseThis(){
        window.close();
    }
</script>
<title>CVgen</title>




<script language="javascript">
function check()
{

if(document.form1.name.value=="")
  {
    alert("Plese Enter Your Name");
    document.form1.name.focus();
    return false;
  }
 
 if(document.form1.pass.value=="")
  {
    alert("Plese Enter Your Password");
    document.form1.pass.focus();
    return false;
  } 
  if(document.form1.cpass.value=="")
  {
    alert("Plese Enter Confirm Password");
    document.form1.cpass.focus();
    return false;
  }
  if(document.form1.pass.value!=document.form1.cpass.value)
  {
    alert("Confirm Password does not matched");
    document.form1.cpass.focus();
    return false;
  }
  
 
  if(document.form1.email.value=="")
  {
    alert("Plese Enter your Email Address");
    document.form1.email.focus();
    return false;
  }

  e=document.form1.email.value;
        f1=e.indexOf('@');
        f2=e.indexOf('@',f1+1);
        e1=e.indexOf('.');
        e2=e.indexOf('.',e1+1);
        n=e.length;

        if(!(f1>0 && f2==-1 && e1>0 && e2==-1 && f1!=e1+1 && e1!=f1+1 && f1!=n-1 && e1!=n-1))
        {
            alert("Please Enter valid Email");
            document.form1.email.focus();
            return false;
        }
  return true;
  }
  
</script>


</head>
<body>
    <?php
    include("header.php");
    ?>

 <h1 align="center" > CVautoGEN </h1>

              
      <ul class="nav1">
           <?php 
            if(isset($_SESSION['loggedinstring'])){
                echo $_SESSION['loggedinstring'] ;
              }
            ?>
          
          
      </ul>
      
      
        <div class="boarder">
          <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="#">New</a></li>
            <li><a href="#">View resume</a></li>
          </ul>
        </div>

        <div class="sidebar" align ="center" >
              
                    
                        <div class="col-sm-6 col-sm-offset-3 form-box">
                          <div class="form-top">
                            <div class="form-top-left">
                              <div class="form-top-left">
                              <h3>Register your Details</h3>
                                <label>All field required </label>
                            </div>
                            </div>
                            <div class="form-top-right">
                              <i class="fa fa-key"></i>
                            </div>
                            </div>
                            <div class="form-bottom">


                           <form name="form1" method="post" action="signup.php" onSubmit="return check();"> 
                            
                            <div class="form1">
                                <p class="small">
                                    
                                    <br />
                                    <label class="sr-only" for="form-username"> Username</label>
                                    <input id="form-username"  placeholder="Username..." type="text" size="42" name="name"  />
                                    <br />
                                    
                                    <label class="sr-only" for="form-password">Password </label>
                                    <input id="form-password"   placeholder="password..."type="password" size="42" name="pass" />
                                    <br />
                                    <label class="sr-only" for="form-cpassword">Confirm your assword </label>
                                    <input id="form-cpassword" type="password"   placeholder="Re-enter your password..."size="42" name="cpass" />
                                    <br />
                                    
                                    <label class="sr-only" for="form-email">E-mail</label>
                                    <input id="form-email"  placeholder="Enter your mail..."type="text" size="42" name="email"/>
                                    <br />
                                    
                                </p>
                            </div>
                            
                                <button href="getDetails.php" class="btn btn-lg btn-primary btn-block" name="submit" type="submit" >Sign-Up</button>
                            </div>
                        </form>



                        </div>
                        </div>
                   
                    
                        
                    
                
       
        </div>




     
        <script src="assets/js/jquery-1.11.1.min.js"></script>
       <script src="assets/bootstrap/js/bootstrap.min.js"></script>
       
        <script src="assets/js/scripts.js"></script>
    </body>
  
</html>






   



</body>
</html>