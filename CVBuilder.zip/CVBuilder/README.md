# Resume-Builder
A website built in PHP that builds a simple resume.

It is built using PHP and uses some Javascript CSS and Bootstrap. While the code is functional, it is not deployed and its db backend needs to be restored for it to work.

This is an example of some of my work in PHP.

Thanks for looking!
