<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    
    
   <!--  <link rel="icon" href="../../favicon.ico"> -->

    <!-- Bootstrap core CSS -->
    

    <!-- Custom styles for this template -->
    <link href="navbar-top.css" rel="stylesheet">
    <link rel="stylesheet" href="../../style.css">
    <link rel="shortcut icon" href="../../dummy/logo.png">
    <title>CVautoGen</title>
    <link href="../../../x.css" rel="stylesheet" type="text/css" />

<link href="../../dist/css/bootstrap.min.css" rel="stylesheet">


    
  </head>
    <body bgcolor="Wheat">
      <h1 align="center" > CVautoGEN </h1>
      <div class="nav1">
         <ul >
             <?php 
              if(isset($_SESSION['loggedinstring'])){
                  echo $_SESSION['loggedinstring'] ;
                }
              ?>
            <fb:login-button autologoutlink="true" perms="user_likes" size="large"></fb:login-button>
            <li><a href="..\..\..\logout.php" onclick="logout()">logout</a></li>
          </ul>
      </div>

         <div class="boarder">
          <ul>
            <li><a href="..\..\..\index.php">Home</a></li>
            <li><a href="getDetails.php ">New</a></li>
            <li><a href="..\..\..\resume.php">View resume</a></li>
          </ul>
        </div>

        <div class="sidebar">
        <nav id="mainNav" class="navbar navbar-default navbar-fixed-top navbar-custom">
        <div class="container">

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#page-top"></a>
                    </li> 
                    </li>
                    <li class="page-scroll">
                        <a href="#Qualification">Qualification</a>
                    </li>
                    <li class="page-scroll">
                        <a href="#Register">Register</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

    
      <section id="Register">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2">
                    <form name="RegistrationForm" id="RegistrationForm" action="STD_newApplicant.php" method="post" enctype="multipart/form-data">
                    <br>
                    <div class="col-lg-12 text-center">
                        <b>PERSONAL DETAILS</b>
                        </div>
                        <br>
                        
                        <div class="row control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                                <label>Full Name</label>
                                <input type="text" class="form-control" placeholder="Student's Full Name" name="name" required text="Please enter your name.">
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>
                        
                        <div class="row control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                                <label>NIC No</label>
                                <input type="text" class="form-control" placeholder="NIC No" name="nic" required text="Please enter your NIC.">
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>
                        <div class="row control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                                <label>Date of Birth</label>
                                <input type="date" class="form-control" placeholder="Date of Birth(YYYY-MM-DD)" name="DOB" required text="Please enter your date of birth.">
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>
                        <div class="row control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                                <label>Gender</label>
                                <select name="Gender" class="form-control" required text="Please select Gender.">
                                <optgroup label="Gender:">
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                </optgroup>
                                </select>
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>
                        <div class="row control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                                <label>Job Title</label>
                                <select name="Faculty" class="form-control" required text="Please select Faculty.">
                                    <optgroup label="Faculties:">
                                    <option value="Software engineer">Software engineer</option>
                                    <option value="civil engineer" checked>civil engineer</option>
                                    <option value="Teacher">Teacher</option>
                                    <option value="Accountant">Accountant</option>
                                    <option value="medicine" checked>Doctor</option>
                                    <option value="Web designer" checked>Web designer</option>
                                    <option value="Lecturer" checked>Lecturer</option>
                                    </optgroup>
                                </select>
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>
                        
                        <div class="row control-group">
                            <div class="col-lg-12 text-center">
                            <br>
                            <b>CONTACT DETAILS</b>
                            <br>
                                
                                <input type="text" class="form-control" placeholder="Phone Number" name="phone" required text="Please enter your phone number.">
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>
                        
                        <div class="row control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                                
                                <input type="email" class="form-control" placeholder="Email Address(example@email.com)" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required text="Please enter your email address.">
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>
                        <div class="row control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                                
                                <input type="text" class="form-control "placeholder="Student residential address" name="Saddress" required text="Please enter your residential address.">
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>              
                        <br>
                      
                   
                </div>
            </div>
        
    
    <section class="success" id="Qualification">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2>Qualification</h2>
                    <hr class="star-primary">
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-lg-offset-2">
                    <form name="RegistrationForm" id="RegistrationForm" action="new_con.php" method="post" enctype="multipart/form-data">
                     <div class="row control-group">
                          <div class="form-group col-xs-12 floating-label-form-group controls">
                              <label>Educational Qulaifications</label>
                              <input type="text" class="form-control" placeholder="Write here" name="name" required text="Please enter your educational qualifications.">
                              <p class="help-block text-danger"></p>
                          </div>
                      </div>

                </div>
            </div>
        
   


                  <section id="Register">
                     <div class="container">
                        <div class="row">
                            <div class="col-lg-8 col-lg-offset-2">
                                <b> UPLOAD A PHOTOGRAPH</b>
                                <br>
                                <div class="row control-group">
                                    <div class="form-group col-xs-12 floating-label-form-group controls">
                                         <input name="pro_Picture" type="file" required text="Please upload a photograph."/>
                                        <p class="help-block text-danger"></p>
                                    </div>
                                </div>
                                <br>
                                <b> I here by certify that everything stated above are true to my best knowledge.</b>
                                <br>
                                <br>
                                <div id="success"></div>
                                <div class="row">
                                    <div class="form-group col-xs-12">
                                        <button type="submit" class="btn btn-success btn-lg"> Submit </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </section>
              </form>
              </div>
               </section>
          </div>
     </section>
    <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes) -->
    <div class="scroll-top page-scroll hidden-sm hidden-xs hidden-lg hidden-md">
        <a class="btn btn-primary" href="#page-top">
            <i class="fa fa-chevron-up"></i>
        </a>
    </div>
     <!-- Bootstrap Core JavaScript -->
    <script src="../../dist/js/bootstrap.min.js"></script>
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
        </div>


      </div>

    </body>
  
</html>