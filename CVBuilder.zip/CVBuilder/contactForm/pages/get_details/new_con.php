<?php

include('connection.php');
// basic info
$fullName = $_POST["full_name"];
/*$iniName = $_POST["iniName"];*/
$gender = $_POST["gender"];
$nic = $_POST["NIC_no"];
$dob = $_POST["Date_Of_Birth"];
$job = $_POST["job_title"];
/*$course = $_POST["Course"];
$year = $_POST["year"];*/
// Student contact details
$contactNo = $_POST["Mobile"];
$email = $_POST["email"];
/*$resAddress = $_POST["Saddress"];
$district = $_POST["SDistrict"];
$gsDiv = $_POST["GSD"];
$dsDiv = $_POST['DSD'];*/

if(isset($fullName,$gender,$nic,$dob,$job,$contactNo,$email))
{
$sql = "INSERT INTO new_user (full_name,gender,nic,dob,job,contactNo,email) VALUES ('".$fullName."', '".$gender."', '".$nic."', '".$dob."', '".$job."', '".$contactNo."', ".$email.", 0);";
// sql for student contact details
/*$sql_Contact = "INSERT INTO new_student_contact(reg_no, contact_no, email, resedential_adress, district, gs_devision, ds_devision) VALUES ('".$regNo."','".$contactNo."','".$email."','".$resAddress."','".$district."','".$gsDiv."','".$dsDiv."')";*/
// sql for gurdian details
/*$sql_Gurdian = "INSERT INTO new_gurdian_detail (`reg_no`, `gurdian_name`, `relationship`, `contact_no`, `adress`, `police_station`) VALUES ('".$regNo."', '".$gname."', '".$relation."', '".$GcontNo."', '".$GAddress."', '".$GPoliceStation."');";*/

// upload photo
//file properties
$file = $_FILES['pro_Picture']['tmp_name'];
$isImgSet = FALSE;
if(!isset($file))
{
	echo "please select image";
}
else
{
	$img = addslashes(file_get_contents($file));
	$img_name = addslashes($_FILES['pro_Picture']['fullname']);
	$img_size = getimagesize($file);

	if($img_size == FALSE)
	{
		echo "thats not an image";
	}
	else
	{
		$sql_img = "INSERT INTO `student_Pic`(`NIC_no`, `fullname`, `Image`) VALUES ('$regNo','$img_name','$img');";
		if($conn->query($sql_img) === TRUE)
			$isImgSet = TRUE;
	}
} 
$conn->query($sql); 
/*$conn->query($sql_Contact);*/
$conn->query($sql_img) ;

	
	header("Location:Success.php#Register");
}
else
{

}
?>
