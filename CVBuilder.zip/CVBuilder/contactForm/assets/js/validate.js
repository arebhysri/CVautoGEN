<script>
			function validate()
			{
				if(document.details.fullname.value=="")
				{
					alert("enter your name.");
					document.details.fullname.focus();
					return false;
				}
				if(document.details.paddress.value=="")
				{
					alert("enter your postal address.");
					document.details.paddress.focus();
					return false;
				}
				if(details.gender[0].checked==false)&&(details.gender[1].checked==false)
				{
					alert ("pls choose your gender:male or female");
					return false;
				}
				if(document.details.field.value=="-1")
				{
					alert("enter the field.");
					//document.details.address.focus();
					return false;
				}
				var email=document.details.mailId.value;
				atpos=email.indexOf("@");
				dotpos=email.lastIndexOf(".");
				if(email=="" || atpos<1 ||(dotpos - atpos<2))
				{
					alert("Please enter correct email id");
					document.details.mailId.focus();
					return false;
				}
				return true;
			}
		</script>