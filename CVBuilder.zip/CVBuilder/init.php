<?php
  //ini_set('allow_url_fopen', "On");


  session_start();

  $client_id ="861yf5khv7aq6r";
  $client_secret ="5fn1XJjkPjRUhwJH";
  $redirect_uri ="http://localhost:1024/CVBuilder/callback.php";
  $csrf_token =  mt_rand(11111111,99999999);
  $scopes ="r_basicprofile%20r_emailaddress";



  function curl($url, $parameters){
  	$ch = curl_init();
  	curl_setopt($ch, CURLOPT_URL, $url);
  	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  	curl_setopt($ch, CURLOPT_POSTFIELDS, $parameters);
  	curl_setopt($ch, CURLOPT_POST, 1);
  	$headers =[];
  	$headers [] = "Content-Type: application/x-www-form-urlencoded";
  	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
  	$result =curl_exec($ch);
    	return $result;
  }
    

  function getCallback(){
  	 $client_id ="861yf5khv7aq6r";
	  $client_secret ="5fn1XJjkPjRUhwJH";
	  $redirect_uri ="http://localhost:1024/CVBuilder/callback.php";
	  $csrf_token =  mt_rand(11111111,99999999);
	  $scopes ="r_basicprofile%20r_emailaddress";


  		if(isset($_REQUEST['code'])){
  			$code =$_REQUEST['code'];
  			$url="http://www.linkedin.com/oauth/v2/accessToken";
  			$params =[
  				'client_id'=>$client_id,
  				'client_secret'=>$client_secret,
  				'redirect_uri'=>$redirect_uri,
  				'code'=>$code,
  				'grant_type'=>'authorization_code',
  			];



      // if(ini_set('allow_url_fopen', "On")){

        $accessToken= curl($url,http_build_query($params));
        $accessToken =json_decode($accessToken)->access_token;
          $url = "https://api.linkedin.com/v1/people/~:(id,firstname::(original),email-address)?format=json&oauth2_access_token=". $access_Token;
         // echo "fopen now works";
          $video_info = json_decode ( file_get_contents ( $url ), true );     

         // $user = file_get_contents($url, false);

       /* }
       else{
          echo "hmm..function is not working";
        }*/

  		}
  }
?>

