<?php
function changeSessionID () {
	$server = $_SERVER['SERVER_NAME'];
	$secure = usingHTTPS();
	session_set_cookie_params(0, "/", $server, $secure, true);
	session_regenerate_id(true);
}


function usingHTTPS () {
	return isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] != "off");
}


function redirectToHTTPS()
{
	if(!usingHTTPS())
	{
		$redirect = "https://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
		header("Location:$redirect");
		exit();
	}
}


function verifyLogin ($role) {
	
	
	if (isset($_SESSION['realname'])) {
		
		
		if ($role == '' || (isset($_SESSION['roles']) && in_array($role, $_SESSION['roles']))) {
			
			return $_SESSION['realname'];            
		}
		else {
			require 'view/page_badRole.php';       
			exit();
		}
		
	}
	
	
	$message = "";

	
		if (isset($_REQUEST['username']) && isset($_REQUEST['password'])) {
			$username = $_REQUEST['username'];
			$password = $_REQUEST['password'];
			try {
				$DBH = openDBConnection();
				
				
				$stmt = $DBH->prepare("select Login, RealName, PW from Users where Login = ?");
				$stmt->bindValue(1, $username);
				$stmt->execute();
				
				
				if ($row = $stmt->fetch()) {
					
					
					$hashedPassword = $row['PW'];
					if (computeHash($password, $hashedPassword) == $hashedPassword) {
						$_SESSION['realname'] = 
							htmlspecialchars($row['RealName']);
						$_SESSION['username'] = $username;
						$stmt->closeCursor();
						$stmt = $DBH->prepare("select Role from Roles where Login = ?");
						$stmt->bindValue(1, $username);
						$stmt->execute();
						$roles = array();
						while ($row = $stmt->fetch()) {
							$roles[] = $row['Role'];
						}
						$_SESSION['loggedinstring'] = 'Logged in as: ' . $_SESSION['realname'];
						$_SESSION['roles'] = $roles;
					}
					else {
						$message = "Username or password was wrong";
						require "application/login.php";
						exit();
					}
				}
				else {
					$message = "Username or password was wrong";
					require "application/login.php";
					exit();
				}
			}
			catch (PDOException $exception) {
				require "view/error.php";
				exit();
			}
			
			
			changeSessionID();
			if ($role == '' || in_array($role, $_SESSION['roles'])) {
				return;                                  
			}
			else {
				require 'view/page_badRole.php';      
				exit();
			}
		}
		else {
			require 'application/login.php';
			exit();
		}
	
	}

function makeSalt () {
	$salt = strtr(base64_encode(mcrypt_create_iv(16, MCRYPT_DEV_URANDOM)), '+', '.');
	return '$2a$12$' . $salt;
}


function computeHash ($password, $salt) {
	return crypt($password, $salt);
}
?>