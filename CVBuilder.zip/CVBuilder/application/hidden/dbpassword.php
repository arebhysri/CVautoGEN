<?php
$dbpassword = '00378425';
?>
