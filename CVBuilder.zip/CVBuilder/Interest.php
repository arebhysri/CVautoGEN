<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta name="Description" content="CVgen is a CVs management system" />
<meta name="Keywords" content="CV, CVs, cvgen, contents management system" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="Distribution" content="Global" />
<meta name="Robots" content="index,follow" />
<link rel="shortcut icon" href="themes/default/images/fav.ico" type="image/x-icon" />
<link rel="stylesheet" href="themes/default/stylesheets/reset-min.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="themes/default/stylesheets/layout.css" />
<link rel="stylesheet" type="text/css" href="themes/default/stylesheets/forms.css" />

<script src="themes/default/js/jquery-1.2.6.min.js" type="text/javascript"></script>
<script src="themes/default/js/jquery.validate.min.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript">
	function ColseThis(){
		window.close();
	}
</script>
<title>CVgen</title>
</head>

<body>

<!-- Container -->
<div id="container">

<!-- Header -->
<div id="header">
	<div class="logo">
        <a href="?">
        <img src="themes/default/images/logo.jpg" alt="cvBanke logo" width="187" height="69" />      
        </a>
        <span class="welcom">
                    <p class="header-icons">
                <a href="?jobseeker=jobseeker">
                <img src="themes/default/images/account.png" title="account" alt="account" width="24" height="24" />
                </a>&nbsp;
                <a href="?jobseeker=profile">
                <img src="themes/default/images/profile.png" title="profile" alt="profile" width="24" height="24" />
                </a>&nbsp;
                <a href="?logout">
                <img src="themes/default/images/exit.png" title="logout" alt="Logout" width="24" height="24" />
                </a>
            </p>
                    </span>
    </div>
            <div class="menu">
            <a href="home.php">Home</a> | 
            <a href="education.php">Education</a> |
            <a href="skills.php">Skills</a> | 
            <a href="experience.php">Work experience</a> |
            <a href="interest.php">Interests</a> | 
            <a href="information.php">Information</a> | 
            <a href="references.php">References</a> |
            <a href="showcv.php">Show CV</a>
        </div>
        
</div>
<!-- End Header -->

<!-- content -->
<div id="content">

	


 
        <table class="showtable">
			<tr>
				<th style="width: 15px; text-align: center">Interest</th>
                <th style="width: 100px; text-align: center">Options </th>
			</tr>
                        <tr class="colorBG2" >
                <td style="width: 300px;">Reading</td>
                <td style="width: 100px; text-align: center">
					<a class="del" href="?jobseeker=deleteInterests&id=12" target="_self" title="Delete">
					</a>
                    &nbsp;&nbsp;
					<a class="edit" href="?jobseeker=updateInterests&id=12" target="_self" title="Edit">							
					</a>
				</td>
            </tr>
                    </table>
        <div >
            <a class="button" href="?jobseeker=addInterests" style="float: right; padding: 6px 15px">
			    <img src="themes/default/images/add.png" style="border: 0px;" />&nbsp;
				Add new interest            </a>
        </div>
        </div>
<!-- End content -->

<!-- footer -->
<div id="footer">Copyright 2015 | All Rights Reserved</div>
<!-- End footer -->

<!-- End container -->
</div>
</body>

</html>
