
<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <title>CVautoGen</title>
    <link href="x.css" rel="stylesheet" type="text/css" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Favicon and touch icons -->
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">
         <link href="fonts/font-awesome.min.css" rel="stylesheet" type="text/css">
        <!-- Loading main css file -->
        <link rel="stylesheet" href="style.css">
        <script src="../js/ie-emulation-modes-warning.js"></script>
        <meta charset="utf-8">

        
        
  </head>
    <body>
      <?php
  require_once "init.php";
?>

         <?php
            include("header.php");
            include("connection.php");
            extract($_POST);

            if(isset($submit))
            {
              $rs=mysql_query("select * from users where username='$username' and pass='$pass'");
              if(mysql_num_rows($rs)<1)
              {
                $found="N";
              }
              else
              {
                $_SESSION[login]=$username;
              }
            }
            if (isset($_SESSION[login]))
            {
              echo "$_SESSION[login]=$username";
            header("Location:contactForm/pages/get_details/getDetails.php");
               
                exit;
                

            }


            ?>

      <h1 align="center" > CVautoGEN </h1>

              
      <ul class="nav1">
           <?php 
            if(isset($_SESSION['loggedinstring'])){
                echo $_SESSION['loggedinstring'] ;
              }
            ?>
          
          
      </ul>
      
      
        <div class="boarder">
          <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="#">New</a></li>
            <li><a href="#">View resume</a></li>
          </ul>
        </div>

        <div class="sidebar" align ="center" >
              
                    
                        <div class="col-sm-6 col-sm-offset-3 form-box">
                          <div class="form-top">
                            <div class="form-top-left">
                              <h3>Login to our site</h3>
                                <p>Enter your username and password to log on:</p>
                            </div>
                            <div class="form-top-right">
                              <i class="fa fa-key"></i>
                            </div>
                            </div>
                            <div class="form-bottom">


                          <form name="form1" action="" method="post" class="login-form">


                            <div class="form-group">
                              <label class="sr-only" for="form-username">Username</label>

                                <input type="text" name="username" placeholder="Username..." class="form-username form-control" id="form-username" required autofocus>

                              </div>
                              <div class="form-group">
                                <label class="sr-only" for="form-password">Password</label>
                                <input type="password" name="pass" placeholder="Password..." class="form-password form-control" id="form-password" required autofocus>
                              </div>

                              <div class="checkbox">
                                <label>
                                  <input type="checkbox" value="remember-me"> Remember me
                                </label>
                              </div>
                                 <td colspan="2"><span class="errors">
                                      <?php
                                if(isset($found))
                                {
                                  echo "Invalid Username or Password";
                                }
                                ?>
                                    </span></td>
                              <button href="getDetails.php" class="btn btn-lg btn-primary btn-block" name="submit" type="submit" id="submit" value="Login">Sign in!</button></br>




                              <p align="center">if you don't have account please Signup here</p>

                              <tr>
                                <td colspan="2" bgcolor="#CC3300"><div align="center"><span class="style4"></br>
                                  <a href="jobseeker_register.php">Signup Free</a></span></div></td>
                                </tr>

                          </form>
                        </div>
                        </div>
                   
                        <div class="col-sm-6 col-sm-offset-3 social-login">
                          <p>...or login with:</p>
                          <div class="social-login-buttons">
                            <a class="btn btn-link-1 btn-link-1-facebook" href="#" >
                              <script type="text/javascript" src="./fblogin/fb.js"></script>
                              <fb:login-button 
                                  id="fb-btn"
                                  scope="public_profile,email"
                                  onlogin="checkLoginState();">
                                </fb:login-button>
                            </a>
                            <?php
                              if(isset($_SESSION['name'])){
                                echo $_SESSION['name'];
                              }
                            ?>
                                
                            
                            <a href="<?php echo "https://www.linkedin.com/oauth/v2/authorization?response_type=code&client_id={$client_id}&redirect_uri={$redirect_uri}&state={$csrf_token}&scope={$scopes}"; ?>">
                  <img src="Logo-2C-41px-R.png" alt="logo" width="95" height ="45">
                </a>
                          </div>
                        </div>
                    
                
       
        </div>




     
        <script src="assets/js/jquery-1.11.1.min.js"></script>
       <script src="assets/bootstrap/js/bootstrap.min.js"></script>
       
        <script src="assets/js/scripts.js"></script>
    </body>
  
</html>


